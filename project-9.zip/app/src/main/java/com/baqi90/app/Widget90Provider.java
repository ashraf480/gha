package com.baqi90.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.chrono.HijrahDate;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;

/** ويدجت الشاشة الرئيسية: التاريخ الهجري + الأيام المتبقية + نسبة الإنجاز. يتحدث كل منتصف ليل. */
public class Widget90Provider extends AppWidgetProvider {
    static final String PREFS = "widget";
    static final String ACTION_TICK = "com.baqi90.app.WIDGET_TICK";
    private static final int DAYS = 90;

    private static final String[] WEEK = {"الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"};
    private static final String[] HMONTHS = {"محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
            "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"};

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        update(c);
        scheduleNext(c);
    }

    @Override
    public void onEnabled(Context c) {
        update(c);
        scheduleNext(c);
    }

    @Override
    public void onDisabled(Context c) {
        // لا نلغي التحديث اليومي إذا بقي الويدجت الآخر على الشاشة
        if (hasWidgets(c)) return;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(tickIntent(c));
    }

    private static boolean hasWidgets(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] a = m.getAppWidgetIds(new ComponentName(c, Widget90Provider.class));
            int[] b = m.getAppWidgetIds(new ComponentName(c, Widget90HabitsProvider.class));
            return (a != null && a.length > 0) || (b != null && b.length > 0);
        } catch (Throwable t) {
            return false;
        }
    }

    @Override
    public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        String a = intent.getAction();
        if (a == null) return;
        // أي حدث يغيّر اليوم أو الوقت أو الإقلاع: نحدّث الأرقام ونعيد جدولة منتصف الليل
        if (ACTION_TICK.equals(a) || Intent.ACTION_DATE_CHANGED.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(a) || Intent.ACTION_BOOT_COMPLETED.equals(a)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            update(c);
            scheduleNext(c);
        }
    }

    private static PendingIntent tickIntent(Context c) {
        Intent i = new Intent(c, Widget90Provider.class).setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(c, 7001, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** يجدول التحديث التالي بعد منتصف الليل بخمس ثوانٍ. */
    public static void scheduleNext(Context c) {
        try {
            long t = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).plusSeconds(5).toInstant().toEpochMilli();
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, tickIntent(c));
        } catch (Throwable ignored) { }
    }

    /** يحدّث الويدجتين معًا: الإنجاز الكلي، وإنجاز قسم كسر العادات (دون أي اسم عادة). */
    public static void update(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            push(c, m, Widget90Provider.class, "pct", "الإنجاز الكلي ");
            push(c, m, Widget90HabitsProvider.class, "pct_habits", "إنجاز كسر العادات ");
        } catch (Throwable ignored) { }
    }

    private static void push(Context c, AppWidgetManager m, Class<?> cls, String pctKey, String label) {
        try {
            int[] ids = m.getAppWidgetIds(new ComponentName(c, cls));
            if (ids == null || ids.length == 0) return;
            m.updateAppWidget(ids, build(c, pctKey, label));
        } catch (Throwable ignored) { }
    }

    private static String ar(long n) {
        StringBuilder sb = new StringBuilder();
        for (char ch : String.valueOf(n).toCharArray()) sb.append(Character.isDigit(ch) ? (char) ('٠' + (ch - '0')) : ch);
        return sb.toString();
    }

    private static RemoteViews build(Context c, String pctKey, String pctLabel) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String start = sp.getString("start", "");
        int hadj = sp.getInt("hadj", 0);
        int pct = Math.max(0, Math.min(100, sp.getInt(pctKey, 0)));

        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget90);
        Intent open = new Intent(c, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        rv.setOnClickPendingIntent(R.id.w_root,
                PendingIntent.getActivity(c, 7002, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        LocalDate today = LocalDate.now();
        String hijri;
        try {
            HijrahDate h = HijrahDate.from(today.plusDays(hadj));
            hijri = WEEK[today.getDayOfWeek().getValue() % 7] + " " + ar(h.get(ChronoField.DAY_OF_MONTH)) + " "
                    + HMONTHS[h.get(ChronoField.MONTH_OF_YEAR) - 1] + " " + ar(h.get(ChronoField.YEAR)) + "هـ";
        } catch (Throwable t) {
            hijri = WEEK[today.getDayOfWeek().getValue() % 7];
        }
        rv.setTextViewText(R.id.w_hijri, hijri);

        if (start == null || start.isEmpty()) {
            rv.setTextViewText(R.id.w_num, ar(DAYS));
            rv.setTextViewText(R.id.w_lbl, "يوم متبقٍّ");
            rv.setTextViewText(R.id.w_sub, "افتح التطبيق لتحديد تاريخ البداية");
            rv.setProgressBar(R.id.w_bar, 100, 0, false);
            rv.setTextViewText(R.id.w_pct, "");
            return rv;
        }

        long idx;
        try { idx = ChronoUnit.DAYS.between(LocalDate.parse(start), today); } catch (Throwable t) { idx = 0; }
        long remain;
        String sub;
        if (idx < 0) { remain = DAYS; sub = "يبدأ التحدي بعد " + ar(-idx) + " يوم"; }
        else if (idx >= DAYS) { remain = 0; sub = "انتهت الأيام الـ ٩٠ — تقبّل الله منك"; }
        else { remain = DAYS - idx; sub = "اليوم " + ar(idx + 1) + " من " + ar(DAYS); }

        rv.setTextViewText(R.id.w_num, ar(remain));
        rv.setTextViewText(R.id.w_lbl, "يوم متبقٍّ");
        rv.setTextViewText(R.id.w_sub, sub);
        rv.setProgressBar(R.id.w_bar, 100, pct, false);
        rv.setTextViewText(R.id.w_pct, pctLabel + ar(pct) + "٪");
        return rv;
    }
}
