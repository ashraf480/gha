package com.baqi90.app;

/** ويدجت ثانٍ بنفس شكل الأول تمامًا، لكن نسبة الإنجاز فيه خاصة بقسم «كسر العادات» فقط (ولا يظهر اسم أي عادة). */
public class Widget90HabitsProvider extends Widget90Provider { }
