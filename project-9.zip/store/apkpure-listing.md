# بيانات النشر على APKPure

**اسم التطبيق:** 90 يوم تغيير
**اسم الحزمة (Package):** com.baqi90.app
**الفئة (Category):** Lifestyle (أسلوب حياة)  — أو Productivity
**اللغة:** العربية
**الحد الأدنى لأندرويد:** Android 10 (API 29)
**رابط سياسة الخصوصية:** https://اسم-المستخدم.github.io/اسم-المستودع/privacy.html  ← بعد تفعيل GitHub Pages
**موقع المطوّر:** https://اسم-المستخدم.github.io/اسم-المستودع/

## وصف قصير (Short description)
تابع صلواتك وقرآنك وأذكارك وعاداتك لمدة 90 يومًا، مع التقويم الهجري والتنبيهات.

## الوصف الكامل (Arabic)
تطبيق «90 يوم تغيير» يساعدك على الالتزام بعباداتك وتحسين عاداتك خلال 90 يومًا، بنظام مربعات بسيط وألوان مميزة لكل قسم، ونسبة تقدم تُحسب تلقائيًا لكل قسم.

المميزات:
• الصلاة: الفرائض الخمس والسنن الرواتب والشفع والوتر وقيام الليل والضحى وصلاة التسابيح.
• القرآن الكريم: متابعة الختم والتدبر والحفظ والمراجعة بتواريخ تلقائية.
• الحديث الشريف: 90 حديثًا من رياض الصالحين مع شرح مختصر وتطبيق عملي.
• الأسماء الحسنى: 99 اسمًا بمعانيها وكيفية التعبد بها وذكر لكل اسم مع عدّاد، ومساحة لما استفدته من كل اسم.
• كسر العادات: أربع عادات خاصة بكلمة سر، واسم العادة لا يظهر على الشاشة الرئيسية.
• صيام النوافل: الاثنين والخميس والأيام البيض بالتاريخ الهجري.
• تنظيم النوم والصدقة والدعاء ومربع الشهر الأخير.
• التقويم الهجري: مع تصحيح التاريخ، وملاحظات لكل يوم، وتنبيهات تصل إلى شاشة هاتفك.
• الأذكار: أذكار الصباح والمساء كاملة مع عدّاد للتكرار، و٢٣ خانة لكتابة أي ذكر بنفسك.
• تعديل وحذف أي عنصر في كل الأقسام، ومنبه يومي بالوقت الذي تختاره لكل عنصر.
• ويدجت للشاشة الرئيسية يعرض الأيام المتبقية والتاريخ الهجري ونسبة الإنجاز ويتحدث تلقائيًا كل يوم.
• تصدير تقرير PDF شامل بكل الأقسام.
• يعمل بدون إنترنت، وبياناتك تبقى على جهازك فقط، بدون إعلانات.

## Description (English)
"90 Yawm Taghyeer" helps you stay consistent with your daily worship and habits over 90 days. Track prayers, Sunnah prayers, Quran reading, memorization and review, 90 hadiths with short explanations and practical tips, the 99 Names of Allah, voluntary fasting, charity, sleep and habit-breaking. Includes morning and evening adhkar, editable and deletable items with daily reminders, a Hijri calendar with date correction, notes and reminders, per-section progress, and a full PDF report. Works offline, no ads, and your data never leaves your device.

## الملفات الجاهزة للرفع
- الأيقونة: store/icon-512.png (512×512)
- صورة العرض: store/feature-1024x500.png
- لقطات الشاشة: store/screenshots/ (6 صور 1080×2340)
