# 90 يوم تغيير

تطبيق أندرويد لمتابعة العبادات والعادات على مدى 90 يومًا. يعمل بدون إنترنت، وبياناته على الجهاز فقط.

## المحتويات
- `app/` كود التطبيق (واجهة ويب داخل WebView + كود أندرويد للتنبيهات).
- `docs/` موقع التطبيق (GitHub Pages) + صفحة سياسة الخصوصية.
- `store/` أيقونة ولقطات وبيانات النشر على APKPure.
- `.github/workflows/build-apk.yml` يبني APK موقّعًا وينشر Release تلقائيًا.

## التوقيع (مهم للنشر على APKPure)
أضف 4 أسرار في المستودع: Settings ← Secrets and variables ← Actions ← New repository secret:
`KEYSTORE_BASE64` و `KEYSTORE_PASSWORD` و `KEY_ALIAS` و `KEY_PASSWORD`.
احتفظ بملف المفتاح وكلمات السر في مكان آمن: بدونها لا يمكنك تحديث التطبيق لاحقًا.

## الموقع
بعد أول بناء ناجح يُنشأ فرع `gh-pages` تلقائيًا. ثم: Settings ← Pages ← Source: Deploy from a branch ← Branch: gh-pages ← Folder: / (root) ← Save.
