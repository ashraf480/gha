package com.baqi90.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.graphics.Color;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private WebView printWeb; // يُحتفظ به حتى انتهاء الطباعة

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#0F5C4A"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#F6F1E4"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        web.setWebViewClient(new WebViewClient());
        // بدون WebChromeClient لا تعمل نوافذ alert/confirm في WebView (كان زر الحذف لا يستجيب)
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("حسنًا", (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("نعم", (d, w) -> result.confirm())
                        .setNegativeButton("لا", (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/www/index.html");
        }
    }

    /** جسر بين الواجهة (JavaScript) والتنبيهات الأصلية. */
    public class Bridge {
        @JavascriptInterface
        public void schedule(int id, String millis, String title, String body) {
            askNotificationPermission();
            Reminders.schedule(MainActivity.this, id, Long.parseLong(millis), title, body);
        }

        /** يفتح نافذة الطباعة في أندرويد، ومنها "حفظ كـ PDF". */
        @JavascriptInterface
        public void printHtml(String html) {
            runOnUiThread(() -> {
                printWeb = new WebView(MainActivity.this);
                printWeb.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4).build();
                        pm.print("90-yawm-taghyeer", view.createPrintDocumentAdapter("90-yawm-taghyeer"), attrs);
                    }
                });
                printWeb.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }

        /** يحفظ بيانات الويدجت (تاريخ البداية وتصحيح الهجري ونسبة الإنجاز) ويحدّثه فورًا. */
        @JavascriptInterface
        public void syncWidget(String start, int hadj, int pct) {
            getSharedPreferences("widget", MODE_PRIVATE).edit()
                    .putString("start", start).putInt("hadj", hadj).putInt("pct", pct).apply();
            Widget90Provider.update(MainActivity.this);
            Widget90Provider.scheduleNext(MainActivity.this);
        }

        @JavascriptInterface
        public void cancel(int id) {
            Reminders.cancel(MainActivity.this, id);
        }
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.__back && window.__back()", value -> {
            if (!"true".equals(value)) {
                superBack();
            }
        });
    }

    private void superBack() {
        super.onBackPressed();
    }
}
