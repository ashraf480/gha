package com.baqi90.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.util.Map;

/** جدولة التنبيهات وحفظها لإعادة جدولتها بعد إعادة تشغيل الهاتف. */
public class Reminders {
    private static final String PREFS = "reminders";
    private static final String DAILY = "reminders_daily";

    static PendingIntent pi(Context c, int id, String title, String body) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("id", id);
        i.putExtra("title", title);
        i.putExtra("body", body);
        return PendingIntent.getBroadcast(c, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void schedule(Context c, int id, long millis, String title, String body) {
        schedule(c, id, millis, title, body, false);
    }

    /** daily = true: يتكرر كل يوم في نفس الوقت (يعاد جدولته بعد كل إشعار). */
    public static void schedule(Context c, int id, long millis, String title, String body, boolean daily) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(String.valueOf(id), millis + "\n" + title + "\n" + body).apply();
        c.getSharedPreferences(DAILY, Context.MODE_PRIVATE).edit().putBoolean(String.valueOf(id), daily).apply();
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p = pi(c, id, title, body);
        if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, p);
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, p);
        }
    }

    public static boolean isDaily(Context c, int id) {
        return c.getSharedPreferences(DAILY, Context.MODE_PRIVATE).getBoolean(String.valueOf(id), false);
    }

    /** آخر موعد محفوظ لهذا التنبيه (أو الآن إن لم يوجد). */
    public static long storedMillis(Context c, int id) {
        try {
            String v = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(String.valueOf(id), null);
            if (v != null) return Long.parseLong(v.split("\n", 3)[0]);
        } catch (Exception ignored) { }
        return System.currentTimeMillis();
    }

    /** أول موعد قادم بعد الآن، بنفس الساعة والدقيقة (يراعي تغيّر التوقيت الصيفي). */
    public static long nextAfterNow(long millis) {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.setTimeInMillis(millis);
        long now = System.currentTimeMillis();
        int guard = 0;
        while (cal.getTimeInMillis() <= now && guard++ < 4000) cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
        return cal.getTimeInMillis();
    }

    public static void cancel(Context c, int id) {
        c.getSharedPreferences(DAILY, Context.MODE_PRIVATE).edit().remove(String.valueOf(id)).apply();
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(String.valueOf(id)).apply();
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pi(c, id, "", ""));
    }

    public static void forget(Context c, int id) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(String.valueOf(id)).apply();
    }

    public static void rescheduleAll(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        for (Map.Entry<String, ?> e : sp.getAll().entrySet()) {
            try {
                String[] p = ((String) e.getValue()).split("\n", 3);
                long t = Long.parseLong(p[0]);
                int id = Integer.parseInt(e.getKey());
                boolean daily = isDaily(c, id);
                if (daily) t = nextAfterNow(t);
                if (t > System.currentTimeMillis()) {
                    schedule(c, id, t, p[1], p.length > 2 ? p[2] : "", daily);
                } else {
                    forget(c, id);
                }
            } catch (Exception ignored) { }
        }
    }
}
